#include <stdio.h>

int main() {
    printf("Message 1: Hello, world!\n");
    printf("Message 2: Welcome to C programming!\n");
    printf("Message 3: Have a great day!\n");
    return 0;
}
