#include <stdio.h>

int main() {
    printf("Hello, Dear SY IT STudents!");
    printf("\n       STMT NO-2");
    printf("\n                STMT NO-3");
    printf("                         STMT NO-4");
    
    
    return 0;
}
