#include <stdio.h>
#include <string.h>

int main() {
    char string1[] = "Hello, ";
    char string2[] = "world!";
    char result[50]; // Assuming enough space for concatenation
    
    strcpy(result, string1); // Copy the first string to the result
    strcat(result, string2); // Concatenate the second string to the result

    printf("Concatenated String: %s\n", result);

    return 0;
}
