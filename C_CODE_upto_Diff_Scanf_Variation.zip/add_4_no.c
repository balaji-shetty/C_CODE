#include <stdio.h>

int main() {
    int num1, num2, num3, num4;

    printf("Enter four integer numbers: ");
    scanf("%d %d %d %d", &num4, &num3, &num2, &num1);

    int sum = num1 + num2 + num3 + num4;

    printf("\n num1 numbers: %d", num1);
    printf("\n num2 numbers: %d", num2);
    printf("\n num3 numbers: %d", num3);
    printf("\n num4 numbers: %d", num4);
    printf("\n Sum of the four numbers: %d\n", sum);

    return 0;
}
