#include <stdio.h>

int main() {
    int intValue = 42;
    float floatValue = 3.14159;
    char charValue = 'A';
    double doubleValue = 123.456789;

    printf("Static Input Values:\n");
    printf("Integer: %d\n", intValue);
    printf("Float: %f\n", floatValue);
    printf("Character: %c\n", charValue);
    printf("Double: %lf\n", doubleValue);

    return 0;
}
