#include <stdio.h>

// Data_type  Name_of_var
// int,char, flaot  Seq of char with startig from non_num char and 
//end with any char or no and do not include the space


int main() {
    int intValue = 1242;
    float floatValue = 3.122;
    char charValue = 'H';
   

    printf("Integer: %d", intValue);
    printf("\nFloat: %f\n", floatValue);
    printf("Character: %c\n", charValue);

    return 0;
}
