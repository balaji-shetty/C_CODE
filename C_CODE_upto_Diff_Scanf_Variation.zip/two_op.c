#include <stdio.h>

int main() {
    printf("Message 1: Hello, world!\n");
    printf("Message 2: Welcome to C programming!\n");
    return 0;
}
